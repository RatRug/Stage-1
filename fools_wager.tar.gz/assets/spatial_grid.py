# spatial_grid.py
from collections import defaultdict
from settings import GRID_CELL_SIZE


class SpatialHashGrid:
    """Partitions the 2D arena into fixed-size cells for fast neighborhood queries."""

    def __init__(self, cell_size: int = GRID_CELL_SIZE):
        self.cell_size = cell_size
        self.cells: dict[tuple[int, int], list] = defaultdict(list)

    def clear(self) -> None:
        self.cells.clear()

    def _cell_coords(self, x: float, y: float) -> tuple[int, int]:
        return int(x // self.cell_size), int(y // self.cell_size)

    def insert(self, entity) -> None:
        key = self._cell_coords(entity.pos.x, entity.pos.y)
        self.cells[key].append(entity)

    def query_neighbors(self, x: float, y: float) -> list:
        """Returns all entities in the target cell and its 8 adjacent cells."""
        cx, cy = self._cell_coords(x, y)
        neighbors = []
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                bucket = self.cells.get((cx + dx, cy + dy))
                if bucket:
                    neighbors.extend(bucket)
        return neighbors