# settings.py

# --- Display & Virtual 8-Bit Canvas ---
VIRTUAL_WIDTH = 640
VIRTUAL_HEIGHT = 360
WINDOW_SCALE = 2          # 2x = 1280x720 (3 = 1920x1080)
START_FULLSCREEN = False  # Desktop only; toggle anytime with F11 or Alt+Enter
FPS = 60
WINDOW_TITLE = "Fool's Wager — Stage 1: Kinetic Sandbox"

# --- Bounded Arena & Spatial Grid ---
ARENA_WIDTH = 1600
ARENA_HEIGHT = 1600
TILE_SIZE = 32
GRID_CELL_SIZE = 64  # Spatial hash bucket size (64x64 px)

# --- 8-Bit Grimdark Tarot Palette ---
COLOR_BG = (13, 11, 20)          # #0D0B14 Obsidian stone floor
COLOR_GRID = (26, 22, 38)        # #1A1626 Subtle floor tiles
COLOR_WALL = (58, 48, 74)        # #3A304A Crypt perimeter border
COLOR_BONE = (232, 224, 213)     # #E8E0D5 Player & HUD text
COLOR_GOLD = (244, 180, 27)      # #F4B41B Blessed / Cinder-Flintlock shots
COLOR_CRIMSON = (184, 37, 53)    # #B82535 Ash Crawlers & danger
COLOR_VIOLET = (110, 59, 142)    # #6E3B8E Cursed accents
COLOR_WHITE = (255, 255, 255)    # Hit-flash feedback

# --- Camera ---
CAMERA_SMOOTHNESS = 10.0         # Higher = tighter follow
CAMERA_LOOKAHEAD = 0.15          # Shifts camera 15% toward aim reticle

# --- Player ("The Fool" Stub) ---
PLAYER_SPEED = 145.0
PLAYER_RADIUS = 6.0              # Forgiving circular hitbox
PLAYER_STUB_SIZE = 12
PLAYER_RING_RADIUS = 10
PLAYER_MAX_HP = 5
PLAYER_IFRAMES = 0.85            # Seconds of invulnerability after taking damage

# --- Default Weapon ("Cinder-Flintlock" Stub) ---
FLINTLOCK_COOLDOWN = 0.18
BULLET_SPEED = 420.0
BULLET_RADIUS = 3.0
BULLET_DAMAGE = 12
BULLET_KNOCKBACK = 140.0
BULLET_LIFETIME = 1.2

# --- Enemies ("Ash Crawlers" Stub) ---
CRAWLER_SPEED = 88.0
CRAWLER_RADIUS = 5.0
CRAWLER_STUB_SIZE = 10
CRAWLER_MAX_HP = 24
CRAWLER_SEPARATION_RADIUS = 13.0
CRAWLER_SEPARATION_WEIGHT = 1.35

# --- Spawning ---
INITIAL_SPAWN_INTERVAL = 1.4     # Seconds between wave spawns
SPAWN_BATCH_BASE = 4             # Crawlers per wave at start
SPAWN_MARGIN = 36                # Distance outside camera viewport to spawn