# main.py
import asyncio
import math
import random
import sys
import pygame
from pygame.math import Vector2

import settings as S
from spatial_grid import SpatialHashGrid


class Player:
    def __init__(self, pos: Vector2):
        self.pos = Vector2(pos)
        self.aim_dir = Vector2(1, 0)
        self.hp = S.PLAYER_MAX_HP
        self.max_hp = S.PLAYER_MAX_HP
        self.iframes = 0.0
        self.fire_timer = 0.0

    def update(self, dt: float, keys: pygame.key.ScancodeWrapper, world_mouse: Vector2) -> None:
        if self.iframes > 0:
            self.iframes = max(0.0, self.iframes - dt)
        if self.fire_timer > 0:
            self.fire_timer = max(0.0, self.fire_timer - dt)

        # Normalized 8-directional movement
        move = Vector2(0, 0)
        if keys[pygame.K_w] or keys[pygame.K_UP]:
            move.y -= 1
        if keys[pygame.K_s] or keys[pygame.K_DOWN]:
            move.y += 1
        if keys[pygame.K_a] or keys[pygame.K_LEFT]:
            move.x -= 1
        if keys[pygame.K_d] or keys[pygame.K_RIGHT]:
            move.x += 1

        if move.length_squared() > 0:
            move.normalize_ip()
            self.pos += move * S.PLAYER_SPEED * dt

        # Clamp inside bounded crypt walls
        margin = S.PLAYER_RADIUS + 4
        self.pos.x = max(margin, min(S.ARENA_WIDTH - margin, self.pos.x))
        self.pos.y = max(margin, min(S.ARENA_HEIGHT - margin, self.pos.y))

        # 360-degree twin-stick aim vector
        to_mouse = world_mouse - self.pos
        if to_mouse.length_squared() > 0:
            self.aim_dir = to_mouse.normalize()

    def can_fire(self) -> bool:
        return self.fire_timer <= 0.0

    def reset_fire_timer(self) -> None:
        self.fire_timer = S.FLINTLOCK_COOLDOWN

    def take_damage(self, amount: int = 1) -> bool:
        if self.iframes > 0:
            return False
        self.hp = max(0, self.hp - amount)
        self.iframes = S.PLAYER_IFRAMES
        return True

    def draw(self, surface: pygame.Surface, camera: Vector2) -> None:
        screen_pos = self.pos - camera
        ix, iy = int(round(screen_pos.x)), int(round(screen_pos.y))

        # Outer Fortune/Lantern ring stub
        pygame.draw.circle(surface, S.COLOR_GOLD, (ix, iy), S.PLAYER_RING_RADIUS, 1)

        # Blink during invulnerability frames
        if self.iframes > 0 and int(self.iframes * 20) % 2 == 0:
            body_color = S.COLOR_CRIMSON
        else:
            body_color = S.COLOR_BONE

        half = S.PLAYER_STUB_SIZE // 2
        pygame.draw.rect(surface, body_color, (ix - half, iy - half, S.PLAYER_STUB_SIZE, S.PLAYER_STUB_SIZE))

        # Directional aim barrel line
        tip = screen_pos + self.aim_dir * 12
        pygame.draw.line(surface, S.COLOR_GOLD, (ix, iy), (int(round(tip.x)), int(round(tip.y))), 2)


class Projectile:
    def __init__(self, pos: Vector2, direction: Vector2):
        self.pos = Vector2(pos)
        self.vel = direction * S.BULLET_SPEED
        self.lifetime = S.BULLET_LIFETIME
        self.alive = True

    def update(self, dt: float) -> None:
        self.pos += self.vel * dt
        self.lifetime -= dt
        if self.lifetime <= 0:
            self.alive = False
            return

        # Destroy on arena perimeter wall hit
        if (
            self.pos.x < 4
            or self.pos.x > S.ARENA_WIDTH - 4
            or self.pos.y < 4
            or self.pos.y > S.ARENA_HEIGHT - 4
        ):
            self.alive = False

    def draw(self, surface: pygame.Surface, camera: Vector2) -> None:
        screen_pos = self.pos - camera
        pygame.draw.circle(
            surface,
            S.COLOR_GOLD,
            (int(round(screen_pos.x)), int(round(screen_pos.y))),
            int(S.BULLET_RADIUS),
        )


class AshCrawler:
    def __init__(self, pos: Vector2):
        self.pos = Vector2(pos)
        self.knockback = Vector2(0, 0)
        self.hp = S.CRAWLER_MAX_HP
        self.hit_flash = 0.0
        self.alive = True

    def update(self, dt: float, player_pos: Vector2, grid: SpatialHashGrid) -> None:
        if self.hit_flash > 0:
            self.hit_flash = max(0.0, self.hit_flash - dt)

        # 1. Seek vector toward player
        to_player = player_pos - self.pos
        seek = to_player.normalize() if to_player.length_squared() > 0 else Vector2(0, 0)

        # 2. Soft separation vector from nearby crawlers via Spatial Hash Grid
        separation = Vector2(0, 0)
        sep_rad_sq = S.CRAWLER_SEPARATION_RADIUS ** 2
        for other in grid.query_neighbors(self.pos.x, self.pos.y):
            if other is self or not other.alive:
                continue
            diff = self.pos - other.pos
            dist_sq = diff.length_squared()
            if 0 < dist_sq < sep_rad_sq:
                dist = math.sqrt(dist_sq)
                strength = (S.CRAWLER_SEPARATION_RADIUS - dist) / S.CRAWLER_SEPARATION_RADIUS
                separation += (diff / dist) * strength
            elif dist_sq == 0:
                separation += Vector2(random.uniform(-1, 1), random.uniform(-1, 1))

        steering = seek + separation * S.CRAWLER_SEPARATION_WEIGHT
        if steering.length_squared() > 0:
            steering.normalize_ip()

        # Apply movement + exponentially damped knockback
        self.pos += (steering * S.CRAWLER_SPEED + self.knockback) * dt
        self.knockback *= math.exp(-12.0 * dt)

        # Keep inside arena walls
        margin = S.CRAWLER_RADIUS + 4
        self.pos.x = max(margin, min(S.ARENA_WIDTH - margin, self.pos.x))
        self.pos.y = max(margin, min(S.ARENA_HEIGHT - margin, self.pos.y))

    def take_hit(self, damage: int, impulse: Vector2) -> None:
        self.hp -= damage
        self.knockback += impulse
        self.hit_flash = 0.06
        if self.hp <= 0:
            self.alive = False

    def draw(self, surface: pygame.Surface, camera: Vector2) -> None:
        screen_pos = self.pos - camera
        # Cull off-screen sprites for clean rendering
        if (
            screen_pos.x < -16
            or screen_pos.x > S.VIRTUAL_WIDTH + 16
            or screen_pos.y < -16
            or screen_pos.y > S.VIRTUAL_HEIGHT + 16
        ):
            return

        color = S.COLOR_WHITE if self.hit_flash > 0 else S.COLOR_CRIMSON
        half = S.CRAWLER_STUB_SIZE // 2
        ix, iy = int(round(screen_pos.x)), int(round(screen_pos.y))
        pygame.draw.rect(surface, color, (ix - half, iy - half, S.CRAWLER_STUB_SIZE, S.CRAWLER_STUB_SIZE))


class Game:
    def __init__(self):
        pygame.init()
        self.is_web = sys.platform == "emscripten"
        self.fullscreen = S.START_FULLSCREEN and not self.is_web
        self.set_display_mode()
        pygame.display.set_caption(S.WINDOW_TITLE)

        self.virtual_surface = pygame.Surface((S.VIRTUAL_WIDTH, S.VIRTUAL_HEIGHT))
        self.clock = pygame.time.Clock()
        self.font = pygame.font.SysFont("monospace", 10, bold=True)
        self.big_font = pygame.font.SysFont("monospace", 18, bold=True)

        self.reset_run()

    def set_display_mode(self) -> None:
        size = (S.VIRTUAL_WIDTH * S.WINDOW_SCALE, S.VIRTUAL_HEIGHT * S.WINDOW_SCALE)
        if self.is_web:
            self.window = pygame.display.set_mode(size)
        else:
            flags = pygame.SCALED | (pygame.FULLSCREEN if self.fullscreen else 0)
            self.window = pygame.display.set_mode(size, flags)
        pygame.mouse.set_visible(False)

    def toggle_fullscreen(self) -> None:
        if self.is_web:
            return
        self.fullscreen = not self.fullscreen
        self.set_display_mode()

    def reset_run(self) -> None:
        center = Vector2(S.ARENA_WIDTH / 2, S.ARENA_HEIGHT / 2)
        self.player = Player(center)
        self.camera = center - Vector2(S.VIRTUAL_WIDTH / 2, S.VIRTUAL_HEIGHT / 2)
        self.grid = SpatialHashGrid(S.GRID_CELL_SIZE)
        self.projectiles: list[Projectile] = []
        self.enemies: list[AshCrawler] = []
        self.kills = 0
        self.elapsed_time = 0.0
        self.spawn_timer = 0.5
        self.game_over = False

    def get_virtual_mouse(self) -> Vector2:
        mx, my = pygame.mouse.get_pos()
        return Vector2(mx / S.WINDOW_SCALE, my / S.WINDOW_SCALE)

    def spawn_crawler_wave(self) -> None:
        bonus = int(self.elapsed_time // 20)
        count = S.SPAWN_BATCH_BASE + bonus

        cam_rect = pygame.Rect(
            self.camera.x - S.SPAWN_MARGIN,
            self.camera.y - S.SPAWN_MARGIN,
            S.VIRTUAL_WIDTH + S.SPAWN_MARGIN * 2,
            S.VIRTUAL_HEIGHT + S.SPAWN_MARGIN * 2,
        )

        for _ in range(count):
            for _attempt in range(12):
                sx = random.uniform(20, S.ARENA_WIDTH - 20)
                sy = random.uniform(20, S.ARENA_HEIGHT - 20)
                if not cam_rect.collidepoint(sx, sy):
                    self.enemies.append(AshCrawler(Vector2(sx, sy)))
                    break

    def update(self, dt: float) -> None:
        if self.game_over:
            return

        self.elapsed_time += dt
        virtual_mouse = self.get_virtual_mouse()
        world_mouse = self.camera + virtual_mouse

        # 1. Player & Weapon Update
        keys = pygame.key.get_pressed()
        self.player.update(dt, keys, world_mouse)

        if pygame.mouse.get_pressed()[0] and self.player.can_fire():
            muzzle_pos = self.player.pos + self.player.aim_dir * 10
            self.projectiles.append(Projectile(muzzle_pos, self.player.aim_dir))
            self.player.reset_fire_timer()

        # 2. Spawning & Spatial Grid Rebuild (Enemies never despawn)
        self.spawn_timer -= dt
        if self.spawn_timer <= 0:
            self.spawn_crawler_wave()
            self.spawn_timer = max(0.55, S.INITIAL_SPAWN_INTERVAL - (self.elapsed_time * 0.005))

        self.grid.clear()
        for enemy in self.enemies:
            self.grid.insert(enemy)

        # 3. Update Projectiles & Enemy AI
        for bullet in self.projectiles:
            bullet.update(dt)

        for enemy in self.enemies:
            enemy.update(dt, self.player.pos, self.grid)

        # 4. Collision Resolution via Spatial Hash Grid
        hit_dist_sq = (S.BULLET_RADIUS + S.CRAWLER_RADIUS) ** 2
        for bullet in self.projectiles:
            if not bullet.alive:
                continue
            for enemy in self.grid.query_neighbors(bullet.pos.x, bullet.pos.y):
                if not enemy.alive:
                    continue
                if (bullet.pos - enemy.pos).length_squared() <= hit_dist_sq:
                    impulse = bullet.vel.normalize() * S.BULLET_KNOCKBACK
                    enemy.take_hit(S.BULLET_DAMAGE, impulse)
                    bullet.alive = False
                    if not enemy.alive:
                        self.kills += 1
                    break

        player_hit_sq = (S.PLAYER_RADIUS + S.CRAWLER_RADIUS) ** 2
        for enemy in self.grid.query_neighbors(self.player.pos.x, self.player.pos.y):
            if enemy.alive and (self.player.pos - enemy.pos).length_squared() <= player_hit_sq:
                if self.player.take_damage(1) and self.player.hp <= 0:
                    self.game_over = True
                break

        # Prune dead entities
        self.projectiles = [b for b in self.projectiles if b.alive]
        self.enemies = [e for e in self.enemies if e.alive]

        # 5. Smooth Look-Ahead Camera Clamped to Arena
        mouse_offset = virtual_mouse - Vector2(S.VIRTUAL_WIDTH / 2, S.VIRTUAL_HEIGHT / 2)
        target_cam = (
            self.player.pos
            - Vector2(S.VIRTUAL_WIDTH / 2, S.VIRTUAL_HEIGHT / 2)
            + mouse_offset * S.CAMERA_LOOKAHEAD
        )
        lerp_t = 1.0 - math.exp(-S.CAMERA_SMOOTHNESS * dt)
        self.camera += (target_cam - self.camera) * lerp_t
        self.camera.x = max(0.0, min(S.ARENA_WIDTH - S.VIRTUAL_WIDTH, self.camera.x))
        self.camera.y = max(0.0, min(S.ARENA_HEIGHT - S.VIRTUAL_HEIGHT, self.camera.y))

    def draw_arena(self) -> None:
        self.virtual_surface.fill(S.COLOR_BG)

        start_x = int(self.camera.x // S.TILE_SIZE) * S.TILE_SIZE
        start_y = int(self.camera.y // S.TILE_SIZE) * S.TILE_SIZE

        for x in range(start_x, int(self.camera.x + S.VIRTUAL_WIDTH) + S.TILE_SIZE, S.TILE_SIZE):
            sx = int(round(x - self.camera.x))
            pygame.draw.line(self.virtual_surface, S.COLOR_GRID, (sx, 0), (sx, S.VIRTUAL_HEIGHT))

        for y in range(start_y, int(self.camera.y + S.VIRTUAL_HEIGHT) + S.TILE_SIZE, S.TILE_SIZE):
            sy = int(round(y - self.camera.y))
            pygame.draw.line(self.virtual_surface, S.COLOR_GRID, (0, sy), (S.VIRTUAL_WIDTH, sy))

        wall_rect = pygame.Rect(
            int(round(-self.camera.x)),
            int(round(-self.camera.y)),
            S.ARENA_WIDTH,
            S.ARENA_HEIGHT,
        )
        pygame.draw.rect(self.virtual_surface, S.COLOR_WALL, wall_rect, 4)

    def draw_hud(self, virtual_mouse: Vector2) -> None:
        hp_str = "HP: " + ("♥ " * self.player.hp) + ("· " * (self.player.max_hp - self.player.hp))
        hp_surf = self.font.render(hp_str, False, S.COLOR_CRIMSON)
        self.virtual_surface.blit(hp_surf, (8, 6))

        stats_str = f"TIME: {self.elapsed_time:05.1f}s  KILLS: {self.kills}  HORDE: {len(self.enemies)}"
        stats_surf = self.font.render(stats_str, False, S.COLOR_BONE)
        self.virtual_surface.blit(stats_surf, (S.VIRTUAL_WIDTH - stats_surf.get_width() - 8, 6))

        fps_label = f"FPS: {int(self.clock.get_fps())}"
        if not self.is_web:
            fps_label += "  [F11] Fullscreen"
        fps_surf = self.font.render(fps_label, False, S.COLOR_GOLD)
        self.virtual_surface.blit(fps_surf, (8, S.VIRTUAL_HEIGHT - 16))

        # Custom 8-bit crosshair reticle
        rx, ry = int(round(virtual_mouse.x)), int(round(virtual_mouse.y))
        pygame.draw.line(self.virtual_surface, S.COLOR_BONE, (rx - 4, ry), (rx - 2, ry))
        pygame.draw.line(self.virtual_surface, S.COLOR_BONE, (rx + 2, ry), (rx + 4, ry))
        pygame.draw.line(self.virtual_surface, S.COLOR_BONE, (rx, ry - 4), (rx, ry - 2))
        pygame.draw.line(self.virtual_surface, S.COLOR_BONE, (rx, ry + 2), (rx, ry + 4))

        if self.game_over:
            overlay = pygame.Surface((S.VIRTUAL_WIDTH, S.VIRTUAL_HEIGHT), pygame.SRCALPHA)
            overlay.fill((13, 11, 20, 185))
            self.virtual_surface.blit(overlay, (0, 0))

            title = self.big_font.render("THE FOOL HAS FALLEN", False, S.COLOR_CRIMSON)
            prompt = self.font.render("Press [R] to Wager Again", False, S.COLOR_BONE)
            self.virtual_surface.blit(
                title, ((S.VIRTUAL_WIDTH - title.get_width()) // 2, S.VIRTUAL_HEIGHT // 2 - 18)
            )
            self.virtual_surface.blit(
                prompt, ((S.VIRTUAL_WIDTH - prompt.get_width()) // 2, S.VIRTUAL_HEIGHT // 2 + 8)
            )

    def render(self) -> None:
        virtual_mouse = self.get_virtual_mouse()
        self.draw_arena()

        for bullet in self.projectiles:
            bullet.draw(self.virtual_surface, self.camera)
        for enemy in self.enemies:
            enemy.draw(self.virtual_surface, self.camera)

        self.player.draw(self.virtual_surface, self.camera)
        self.draw_hud(virtual_mouse)

        scaled = pygame.transform.scale(self.virtual_surface, self.window.get_size())
        self.window.blit(scaled, (0, 0))
        pygame.display.flip()

    async def run(self) -> None:
        while True:
            dt = min(self.clock.tick(S.FPS) / 1000.0, 0.05)

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    return
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE and not self.is_web:
                        pygame.quit()
                        return
                    if event.key == pygame.K_F11 or (
                        event.key == pygame.K_RETURN and (event.mod & pygame.KMOD_ALT)
                    ):
                        self.toggle_fullscreen()
                    if event.key == pygame.K_r and self.game_over:
                        self.reset_run()

            self.update(dt)
            self.render()
            await asyncio.sleep(0)


if __name__ == "__main__":
    asyncio.run(Game().run())